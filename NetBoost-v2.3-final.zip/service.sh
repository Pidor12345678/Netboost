#!/system/bin/sh

MODDIR=/data/adb/modules/netboost
TTL_CONF=$MODDIR/ttl.conf
LOCK=$MODDIR/watchdog.lock

mkdir -p $MODDIR

until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done
sleep 8

apply_dns() {
  settings put global private_dns_mode hostname
  settings put global private_dns_specifier one.one.one.one
  setprop net.dns1 1.1.1.1
  setprop net.dns2 1.0.0.1
  setprop net.rmnet0.dns1 1.1.1.1
  setprop net.rmnet0.dns2 1.0.0.1
  setprop net.ppp0.dns1   1.1.1.1
  setprop net.ppp0.dns2   1.0.0.1
  setprop net.dns1_v6        2606:4700:4700::1111
  setprop net.dns2_v6        2606:4700:4700::1001
  setprop net.rmnet0.dns1_v6 2606:4700:4700::1111
  setprop net.rmnet0.dns2_v6 2606:4700:4700::1001
  ndc resolver flushdefaultif 2>/dev/null
}

apply_tcp() {
  sysctl -w net.ipv4.tcp_congestion_control=bbr 2>/dev/null || \
  sysctl -w net.ipv4.tcp_congestion_control=cubic 2>/dev/null

  sysctl -w net.ipv4.tcp_rmem="4096 87380 16777216"
  sysctl -w net.ipv4.tcp_wmem="4096 65536 16777216"
  sysctl -w net.core.rmem_max=16777216
  sysctl -w net.core.wmem_max=16777216
  sysctl -w net.core.rmem_default=16777216
  sysctl -w net.core.wmem_default=16777216
  sysctl -w net.core.optmem_max=16777216
  sysctl -w net.core.netdev_max_backlog=5000
  sysctl -w net.ipv4.tcp_fastopen=3
  sysctl -w net.ipv4.tcp_slow_start_after_idle=1
  sysctl -w net.ipv4.tcp_no_metrics_save=1
  sysctl -w net.ipv4.tcp_syn_retries=2
  sysctl -w net.ipv4.tcp_synack_retries=2
  sysctl -w net.ipv4.tcp_tw_reuse=1
  sysctl -w net.ipv4.tcp_mtu_probing=1
  sysctl -w net.ipv4.tcp_sack=1
  sysctl -w net.ipv4.tcp_window_scaling=1
  sysctl -w net.ipv4.ip_local_port_range="1024 65535"
  sysctl -w net.ipv4.tcp_keepalive_time=60
  sysctl -w net.ipv4.tcp_keepalive_intvl=10
  sysctl -w net.ipv4.tcp_keepalive_probes=6
  sysctl -w net.ipv4.tcp_fin_timeout=15

  sysctl -w net.ipv6.conf.all.accept_ra=2 2>/dev/null
  sysctl -w net.ipv6.conf.default.accept_ra=2 2>/dev/null
  sysctl -w net.ipv6.conf.all.autoconf=1 2>/dev/null
  sysctl -w net.ipv6.conf.default.autoconf=1 2>/dev/null
  sysctl -w net.ipv6.conf.all.use_tempaddr=2 2>/dev/null
  sysctl -w net.ipv6.conf.default.use_tempaddr=2 2>/dev/null
  sysctl -w net.ipv6.ip6frag_time=60 2>/dev/null

  setprop net.tcp.buffersize.default "4096,87380,16777216,4096,16384,16777216"
  setprop net.tcp.buffersize.wifi    "4096,87380,16777216,4096,16384,16777216"
  setprop net.tcp.buffersize.lte     "4096,87380,16777216,4096,16384,16777216"
  setprop net.tcp.buffersize.hspap   "4096,87380,16777216,4096,16384,16777216"
  setprop net.tcp.buffersize.hspa    "4096,87380,16777216,4096,16384,16777216"
  setprop net.tcp.buffersize.umts    "4096,87380,16777216,4096,16384,16777216"
  setprop net.tcp.buffersize.edge    "4096,87380,16777216,4096,16384,16777216"
  setprop net.tcp.buffersize.gprs    "4096,87380,16777216,4096,16384,16777216"
  setprop net.tcp.buffersize.5gnr    "4096,87380,33554432,4096,16384,33554432"
}

apply_ttl() {
  TTL=64
  [ -f "$TTL_CONF" ] && TTL=$(tr -d '[:space:]' < "$TTL_CONF")
  sysctl -w net.ipv4.ip_default_ttl=$TTL
  sysctl -w net.ipv6.conf.all.hop_limit=$TTL 2>/dev/null
  sysctl -w net.ipv6.conf.default.hop_limit=$TTL 2>/dev/null
}

flush_arp() {
  ip neigh flush all 2>/dev/null
  ip -6 neigh flush all 2>/dev/null
}

apply_dns
apply_tcp
apply_ttl
flush_arp

[ -f "$LOCK" ] && kill "$(cat $LOCK)" 2>/dev/null
(
  echo $$ > "$LOCK"
  prev_type=""
  while true; do
    sleep 15

    spec=$(settings get global private_dns_specifier 2>/dev/null)
    mode=$(settings get global private_dns_mode 2>/dev/null)
    if [ "$spec" != "one.one.one.one" ] || [ "$mode" != "hostname" ]; then
      apply_dns
    fi

    cur_ttl=$(cat /proc/sys/net/ipv4/ip_default_ttl 2>/dev/null)
    saved_ttl=64
    [ -f "$TTL_CONF" ] && saved_ttl=$(tr -d '[:space:]' < "$TTL_CONF")
    if [ "$cur_ttl" != "$saved_ttl" ]; then
      apply_ttl
    fi

    net_type=$(getprop gsm.network.type 2>/dev/null)
    if [ "$net_type" != "$prev_type" ] && [ -n "$prev_type" ]; then
      flush_arp
      apply_dns
    fi
    prev_type=$net_type
  done
) &
