#!/system/bin/sh

CONF=/data/adb/modules/netboost/ttl.conf
VALS="64 65 128 60 255"

current=64
[ -f "$CONF" ] && current=$(tr -d '[:space:]' < "$CONF")

next=64
found=0
for v in $VALS; do
  [ $found -eq 1 ] && [ "$next" = "64" ] && next=$v && break
  [ "$v" = "$current" ] && found=1
done

echo "$next" > "$CONF"
sysctl -w net.ipv4.ip_default_ttl=$next
sysctl -w net.ipv6.conf.all.hop_limit=$next 2>/dev/null

echo ""
echo "NetBoost"
echo "TTL: $current -> $next"
echo "64 -> 65 -> 128 -> 60 -> 255 -> 64"
