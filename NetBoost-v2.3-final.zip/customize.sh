#!/system/bin/sh
ui_print ""
ui_print "NetBoost v2.0 by Evtisy"
ui_print ""
ui_print "Reboot to apply."
ui_print ""
